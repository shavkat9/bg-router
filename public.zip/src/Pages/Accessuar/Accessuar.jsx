import React from "react";
import Navbar from '../../components/Navbar/Navbar';
import Access from '../../components/Access/Access';
import './Accessuar.css'

const Accessuar = () => {
    return(
        <div className="accessuar__content">
            < Navbar />
            < Access />
        </div>
    )
}

export default Accessuar;