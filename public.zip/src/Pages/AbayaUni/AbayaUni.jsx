import React from "react";
import Navbar from '../../components/Navbar/Navbar'
import Abaya from '../../components/Abaya/Abaya'
import './Abaya.css'

const AbayaUni = () => {
    return(
        <div className="wedding">
            < Navbar />
            < Abaya />
        </div>
    )
}

export default AbayaUni;