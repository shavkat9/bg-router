import React from "react";
import Navbar from '../../components/Navbar/Navbar';
import Beao from '../../components/Beaos/Beaos';
import './Beauty.css'


const Beaos = () => {
    return (
        <div className="beao">
            < Navbar />
            < Beao />
        </div>
    )
}
export default Beaos;