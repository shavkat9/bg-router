import React from 'react'
import Hero from '../../components/Hero/Hero'
import Navbar from '../../components/Navbar/Navbar'
import './HeroPage.css'

const HeroPage = () => {
  return (
    <div className='heropage'>
        <Navbar />
        <Hero />
    </div>
  )
}

export default HeroPage