import "./App.css";
import React from "react";
import HeaderInput from "./Pages/HeaderInput/HeaderInput";
import { Route, Routes } from "react-router-dom";
import HeroPage from "./Pages/HeroPage/HeroPage";
import Beauty from './Pages/Beauty/Beauty';
import AbayaUni from './Pages/AbayaUni/AbayaUni' ;
import Access from './Pages/Accessuar/Accessuar';
import Section from './components/Section/Section';
import Form from './components/Form/Form'
import Main from './components/Main/Main'

function App() {

  return (
    <div className="App">
       <Routes>
           <Route path="/" element={
            <>
               <HeaderInput />
               < Section />
               <Form />
               < Main />
            </>
           } />
           <Route path="/abay-boutique" element={
            <>
              <HeroPage />
            </>
           } />
           < Route path="/beao" element={ 
            <>
            < Beauty /> 
            </>
           } />
           <Route path="/AbayaUni" element= {
            <>
             < AbayaUni />
            </>
            
           } />
           <Route path="/access" element={ 
           <>
              < Access />
           </>
           } />
       </Routes>
    </div>
  );
}

export default App;

