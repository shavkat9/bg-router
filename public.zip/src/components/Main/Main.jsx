import React from "react";
import './Main.css';
import Stars from '../../assets/img/stars.png'

const Main = () => {
    return(
        <div className="main">
            <div className="main__titles">
                <h2>дадим слова нашим клиентам</h2>
            </div>
            <div className="main__boxes">
                <div className="main__box">
                    <p>Pelit ex tincidunt est. at hendrerit vehicula, malesuada amet, turpis non, venenatis elit non. sapien ipsum gravida placerat.</p>
                    <span>Zarina</span>
                </div>
                <div className="main__box">
                    <p>Pelit ex tincidunt est. at hendrerit vehicula, malesuada amet, turpis non, venenatis elit non. sapien ipsum gravida placerat.</p>
                    <span>Zarina</span>
                </div>
                <div className="main__box">
                    <p>Pelit ex tincidunt est. at hendrerit vehicula, malesuada amet, turpis non, venenatis elit non. sapien ipsum gravida placerat.</p>
                    <span>Zarina</span>
                </div>
                <div className="main__box">
                    <p>Pelit ex tincidunt est. at hendrerit vehicula, malesuada amet, turpis non, venenatis elit non. sapien ipsum gravida placerat.</p>
                    <span>Zarina</span>
                </div>
            </div>
            <div className="main__big__box">
                <div className="main__small__box">
                    <h4>опишите <br /> свое мнение о нас</h4>
                </div>
                <div className="main__middle__box">
                  <p>пишите свой отзыв...</p>        
                </div>
                <div className="main__cursor">
                    <input type="text" />
                    
                <p>согласие на обработку данных</p>
                    <div className="main__stars">
                    <img src={Stars} alt="icon" /> <br />
                    <img src={Stars} alt="icon" /> <br />
                    <img src={Stars} alt="icon" /> <br />
                    <img src={Stars} alt="icon" /> <br />
                    <img src={Stars} alt="icon" /> <br />
                    </div>
                 <button>Отправить отзыв</button>
                </div>
            </div>
        </div>
    )
}
export default Main;