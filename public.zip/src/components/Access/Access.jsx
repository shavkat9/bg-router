import React from "react";
import './Access.css';
import Group from '../../assets/img/group.png'

const Access = () =>{
    return (
        <div className="access__title">
            <div className="access__left">
                <h3>barcha turdagi aksessuarlar</h3>
                <ul>
                    <li><a href="#"></a>️Платки, диадемы и аксессуары</li>
                    <li><a href="#"></a>Qo’l  mehnati</li>
                    <li><a href="#"></a>Dunyo bo’ylab eltib berish xizmati</li>
                </ul>
                <button>Buyurtma berish</button>
            </div>
            <div className="access__img">
                <img src={ Group } alt="img" />
            </div>

        </div>

    )
}
export default Access;