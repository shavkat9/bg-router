import React from "react";
import './Form.css';
import Insta from '../../assets/img/insta.png'
import Foto from '../../assets/img/nice.png'

const Form = () => {
    return(
        <div className="form">
            <div className="form__section">
                <img src={Insta} alt="icon" />
                <p>Подпишитесь на наш инстаграм, чтобы быть в курсе о новых коллекций и скидок</p>
            </div>
            <div className="form__pngs">
                <img src={Foto} alt="img" />
                <img src={Foto} alt="img" />
                <img src={Foto} alt="img" />
                <img src={Foto} alt="img" />
                <img src={Foto} alt="img" />
            </div>
            <button>Перейти в Instagram</button>
        </div>
    )
}

export default Form;