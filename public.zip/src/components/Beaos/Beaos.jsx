import React from "react";
import './Beaos.css'


const Beaos = () => {
    return(
        <div className="beao">
            <div className="beao__container">
                <h3 className="beao__title">Bysohiba brendidan <br />
dubayda ishlangan zamonaviy abayalar</h3>
            </div>
            <ul className="beauty__intro">
                <li>Toshkent, Mirzo G`olib ko’chasi 1</li>
                <li>Har kuni 10:00 - 19:00</li>
            </ul>
        </div>

    )
}

export default Beaos;