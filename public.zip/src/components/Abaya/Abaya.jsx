import React from "react";
import './Abaya.css'

const Abaya = () => {
    return (
        <div className="abaya">
            <div className="abaya__section">
                <h2>Bysohiba brendidan
                 dubayda ishlangan zamonaviy abayalar</h2>
            </div>
            <ul className="abaya__intro">
                <li>Toshkent, Mirzo G`olib ko’chasi 1</li>
                <li>Har kuni 10:00 - 19:00</li>
            </ul>
        </div>

    )
}

export default Abaya;