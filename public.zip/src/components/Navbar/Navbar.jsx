import React from "react";
import './Navbar.css'
import icon from '../../assets/img/logo.png'
import { Link } from "react-router-dom";
import Glob from '../../assets/img/glob.png'

const Navbar = () => {
    return(
        <div className="navbar">
            <div className="container">
                <ul className="navbar-list">
                    <li className="navbar-item">
                        <Link to="/" className="navbar-link">To’y liboslari</Link>
                    </li>
                    <li className="navbar-item">
                        <Link to="/abay-boutique" className="navbar-link">Abaya Boutique</Link>
                    </li>
                    <li className="navbar-item">
                        <Link to="/beao" className="navbar-link">Beauty salon</Link>
                    </li>
                    <li className="navbar-item">
                        <Link to="/AbayaUni"  className="navbar-link">
                            <span>
                                <img src={icon} className="navbar-logo" />
                                <p>weddings</p>
                            </span>
                        </Link>
                    </li>
                    <li className="navbar-item">
                        <Link to="/access"  className="navbar-link">Aksessuarlar</Link>
                    </li>
                    <li className="navbar-item">
                        <a href="tel:+998971018880" className="navbar-link">+998 97 101 88-80</a>
                    </li>
                    <li className="navbar-item">
                        <img src={Glob} alt="icon" className="navbar-link" />
                        <a href="#" className="navbar-link">Рус</a>
                    </li>
                </ul>
            </div>
        </div>
    )
}
export default Navbar;