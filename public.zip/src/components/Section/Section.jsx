import React from "react";
import './Section.css'
import Ladi from '../../assets/img/ladi.png'
import Logo from '../../assets/img/logo.png'


const Section = () => {
    return (
        <div className="section__container">
            <div className="section__title">
                <h3><span>bysohiba </span> предлагает вам следующие Бренды</h3>
            </div>
            <div className="section">
                <div className="section__nav">
                <div className="section__box">
                <div className="section__bar">
                <img src={Ladi} alt="img" />
                </div>
                <div className="section__intro">
                <img src={Logo} alt="" />
                <i>Wedding</i>
                <p>свадебные платья</p>
                </div>
            </div>
            <div className="section__box">
                <div className="section__bar">
                <img src={Ladi} alt="img" />
                </div>
                <div className="section__intro">
                <img src={Logo} alt="" />
                <i>Wedding</i>
                <p>свадебные платья</p>
                </div>
            </div>
                </div>
          
            <div className="section__main">
            <div className="section__box">
                <div className="section__bar">
                <img src={Ladi} alt="img" />
                </div>
                <div className="section__intro">
                <img src={Logo} alt="" />
                <i>Wedding</i>
                <p>свадебные платья</p>
                </div>
            </div>
            <div className="section__box">
                <div className="section__bar">
                <img src={Ladi} alt="img" />
                </div>
                <div className="section__intro">
                <img src={Logo} alt="" />
                <i>Wedding</i>
                <p>свадебные платья</p>
                </div>
            </div>
            </div>
            </div>
           
           
        </div>
    )
}
export default Section;