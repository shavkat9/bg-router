import React from 'react'
import './Hero.css'

const Hero = () => {
  return (
    <div className='hero'>
        <div className="container">
            <h2 className="hero-name">bysohiba to’y liboslari - shariat tanlovi</h2>
        </div>
        <ul className="hero__into">
                <li>Toshkent, Mirzo G`olib ko’chasi 1</li>
                <li>Har kuni 10:00 - 19:00</li>
            </ul>
    </div>
  )
}

export default Hero