import React from "react";
import './Header.css'

const Header = () => {
    return(
        <div className="header">
            <div className="container">
                <h2 className="header-name">бренд, который восхитил многих мусульманских невест по всему миру</h2>
                <button className="header-button">Получить консультацию</button>
            </div>
            <ul className="header__into">
                <li>Toshkent, Mirzo G`olib ko’chasi 1</li>
                <li>Har kuni 10:00 - 19:00</li>
            </ul>
        </div>
    )
}

export default Header